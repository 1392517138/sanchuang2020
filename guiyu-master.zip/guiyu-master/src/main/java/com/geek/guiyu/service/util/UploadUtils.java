package com.geek.guiyu.service.util;

import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class UploadUtils {
    public static String imageUpload(HttpServletRequest request, MultipartFile file, Model model) throws IOException, FileUploadException {
        if (file.isEmpty()) {
            System.out.println("文件为空空");
        }
        // 文件名
        String fileName = file.getOriginalFilename();
        // 后缀名
        String suffixName = fileName.substring(fileName.lastIndexOf("."));
        // 上传后的路径
//        String filePath = "E://upload//";
//        String filePath = "/Users/piwenjing/Desktop/guiyuimage/";
        String filePath = "/data/sanchuang/";
        // 新文件名
        fileName = UUID.randomUUID() + suffixName;
        File dest = new File(filePath + fileName);
        if (!dest.getParentFile().exists()) {
            dest.getParentFile().mkdirs();
        }
        try {
            file.transferTo(dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String filename = "/data/sanchuang/" + fileName;
        model.addAttribute("filename", filename);
        StringBuffer url = request.getRequestURL();
        String tempContextUrl = url.delete(url.length() - request.getRequestURI().length(), url.length()).append("/").toString();
        return tempContextUrl + fileName;
    }
}
