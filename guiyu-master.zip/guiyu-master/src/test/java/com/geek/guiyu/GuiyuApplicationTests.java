package com.geek.guiyu;

import com.geek.guiyu.domain.model.UserInfo;
import com.geek.guiyu.service.UserService;
import com.geek.guiyu.service.util.ShortMessageUtil;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@SpringBootTest
@RunWith(SpringRunner.class)
public class GuiyuApplicationTests {
    @Autowired
    ShortMessageUtil shortMessageUtil;
    @Autowired
    UserService userService;
    @Value("${pagehelper.pageSize}")
    Integer pageSize;
    @Test
    public void test() {
        shortMessageUtil.sendShortMessage("15320263731");
    }
    @Test
    public void testrandom(){
        double random = Math.random() * 1000000;
        System.out.println(String.valueOf((int)random));
    }
    @Test
    public void editUserInfoTest(){
        UserInfo userInfo = new UserInfo();
        userInfo.setPhone("123");
    }
    @Test
    public void testPageSize(){
        System.out.println(pageSize);
    }
    @Test
    public void mapTest(){
        Map<String,Integer> attachment = new HashMap<>();
        attachment.put("hh",1);
        System.out.println(attachment);
    }
}
